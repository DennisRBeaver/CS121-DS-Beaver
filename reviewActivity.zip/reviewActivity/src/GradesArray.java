//Activity #
//Name: Dennis Beaver
//Date of Submissions (9/2/22)

//imports Scanner library
import java.util.Scanner;

public class GradesArray {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number of courses:");
        int numOfCourses = input.nextInt();
        String[] names = new String[numOfCourses + 1];
        int[] credits = new int[numOfCourses + 1];
        int[] scores = new int[numOfCourses + 1];
        char[] grades = new char[numOfCourses + 1];
        for (int i=1; i <= numOfCourses; i++) {
            System.out.println("\n\nEnter course " + i + " name:");
            names[i] = keyboard.nextLine();
            System.out.println("Enter course " + i + " credit hours:");
            credits[i] = input.nextInt();
            System.out.println("Enter course " + i + " score:");
            scores[i] = input.nextInt();
            if (scores[i] >= 90) {
                grades[i] = 'A';
            } else if (scores[i] >= 80) {
                grades[i] = 'B';
            } else if (scores[i] >= 70) {
                grades[i] = 'C';
            } else if (scores[i] >= 60) {
                grades[i] = 'D';
            } else {
                grades[i] = 'F';
            }
        }
        System.out.printf("\n\n%-8s %-8s %-8s %s\n", "Course", "Hours", "Score", "Grade");

        for(int i = 1; i <= numOfCourses; i++) {
            System.out.printf("%-8s  %-8s %-8s %s\n", names[i], credits[i], scores[i], grades[i]);
        }
    }
}
